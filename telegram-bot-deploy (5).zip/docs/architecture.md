# 🏗️ Architecture

![Architecture](../telegram-gemini-architecture.png)

This diagram shows how the bot interacts with Telegram and Gemini API.


[🔝 Back to top](#)
